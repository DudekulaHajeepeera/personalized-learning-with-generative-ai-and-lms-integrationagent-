# EduTutor AI

EduTutor AI is an AI-powered personalized education platform integrating IBM Watsonx and Pinecone.

## Features
- Dynamic quiz generation (Watsonx + Granite)
- Pinecone vector DB for analytics
- Streamlit dashboards for students and educators

## Setup
1. Clone the repo
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and fill in your keys

## Running
- **Backend:**
  ```bash
  uvicorn backend.main:app --reload
  ```
- **Frontend:**
  ```bash
  streamlit run frontend/app.py
  ```

## Environment Variables
See `.env.example` for all required variables. 