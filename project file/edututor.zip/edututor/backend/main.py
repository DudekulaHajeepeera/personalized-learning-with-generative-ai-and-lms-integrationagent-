from fastapi import FastAPI, Body
from typing import Dict, List
from datetime import datetime
from dotenv import load_dotenv
import os
from langchain_ibm import WatsonxLLM
from langchain_core.prompts import PromptTemplate
from pydantic import SecretStr
from pinecone import Pinecone, ServerlessSpec
from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams

load_dotenv()

app = FastAPI()

# Watsonx setup
watsonx_model_id = os.getenv("WATSONX_MODEL_ID")
watsonx_api_key = os.getenv("WATSONX_API_KEY")
watsonx_endpoint = os.getenv("WATSONX_ENDPOINT")
watsonx_project_id = os.getenv("WATSONX_PROJECT_ID")

if not all([watsonx_model_id, watsonx_api_key, watsonx_endpoint, watsonx_project_id]):
    raise RuntimeError("Missing Watsonx environment variables.")

# Configure Watsonx with proper parameters for better MCQ generation
watsonx_params = {
    GenParams.MAX_NEW_TOKENS: 1000,
    GenParams.TEMPERATURE: 0.1,
    GenParams.DECODING_METHOD: "sample"
}

llm = WatsonxLLM(
    model_id=watsonx_model_id,
    apikey=SecretStr(str(watsonx_api_key)),
    url=SecretStr(str(watsonx_endpoint)),
    project_id=watsonx_project_id,
    params=watsonx_params
)

# Pinecone v3 setup
pinecone_api_key = os.getenv("PINECONE_API_KEY")
pinecone_index_name = os.getenv("PINECONE_INDEX_NAME")
if not all([pinecone_api_key, pinecone_index_name]):
    raise RuntimeError("Missing Pinecone environment variables.")

pc = Pinecone(api_key=pinecone_api_key)
if pinecone_index_name not in [idx['name'] for idx in pc.list_indexes()]:
    pc.create_index(
        name=str(pinecone_index_name),
        dimension=1024,
        metric="cosine",
        spec=ServerlessSpec(cloud="aws", region="us-east-1")
    )
index = pc.Index(str(pinecone_index_name))

@app.post('/user/register')
def register_user(user: Dict = Body(...)):
    user_id = user.get('user_id')
    if not user_id:
        return {"error": "user_id is required"}
    return {"message": f"User {user_id} registered successfully."}

@app.post('/login')
def login():
    return {"message": "Login endpoint (manual only)"}

# Helper: Generate MCQs using Watsonx
def generate_mcqs_watsonx(topic: str, difficulty: str, num_questions: int) -> List[Dict]:
    # Use a more explicit format that works better with Watsonx
    prompt = PromptTemplate(
        input_variables=["topic", "difficulty", "num_questions"],
        template=(
            "Create EXACTLY {num_questions} multiple choice questions about {topic} at {difficulty} difficulty level.\n"
            "Do not create more than {num_questions} questions.\n"
            "Format each question as:\n"
            "Question: [question text]\n"
            "A) [option 1]\n"
            "B) [option 2]\n"
            "C) [option 3]\n"
            "D) [option 4]\n"
            "Answer: [A/B/C/D]\n\n"
            "IMPORTANT RULES:\n"
            "1. Each question must have exactly 4 options (A, B, C, D)\n"
            "2. The answer should be the letter (A, B, C, or D) that corresponds to the correct option\n"
            "3. For mathematical questions, provide clean, simple answers (e.g., '7' not '12 - 5 = 7')\n"
            "4. Make sure the correct answer is clearly one of the four options provided\n"
            "5. Avoid repeating the question in the options"
        ),
    )
    prompt_str = prompt.format(topic=topic, difficulty=difficulty, num_questions=num_questions)
    result = llm.invoke(prompt_str)
    print("Watsonx raw result:\n", result)
    
    # Parse Q&A format and convert to JSON structure
    import re
    
    def parse_qa_to_json(text, max_questions):
        """Parse Q&A format and convert to JSON structure"""
        questions = []
        
        # First, try to split by question blocks (Q1:, Q2:, etc.)
        question_blocks = re.split(r'Q\d+:\s*', text)[1:]  # Skip the first empty part
        
        # If no Q1:, Q2: format found, try to find individual questions
        if not question_blocks:
            # Look for patterns like "Question:" or just try to find question-option patterns
            question_blocks = re.split(r'Question:\s*', text)[1:]
        
        # If still no blocks, try to find any question-option pattern
        if not question_blocks:
            # Look for A), B), C), D) patterns and group them
            option_patterns = re.findall(r'[A-D]\)[^A-D]*', text)
            if len(option_patterns) >= 4:  # At least one complete question
                # Extract question text before the first option
                first_option_match = re.search(r'[A-D]\)', text)
                if first_option_match:
                    question_text = text[:first_option_match.start()].strip()
                    # Remove any "Q1:" or "Question:" prefix
                    question_text = re.sub(r'^(Q\d+:|Question:)\s*', '', question_text)
                    
                    # Extract options
                    options = []
                    for option in [r'A\)', r'B\)', r'C\)', r'D\)']:
                        option_match = re.search(rf'{option}\s*([^\n]+)', text)
                        if option_match:
                            options.append(option_match.group(1).strip())
                        else:
                            options.append(f"Option {option[0]}")
                    
                    # Try to find answer
                    answer_match = re.search(r'Answer:\s*([A-D])', text)
                    correct_answer = answer_match.group(1) if answer_match else "A"
                    
                    questions.append({
                        "question": question_text,
                        "options": options,
                        "answer": f"Option {correct_answer}"
                    })
        
        # Process question blocks if found
        for i, block in enumerate(question_blocks):
            # Limit to requested number of questions
            if len(questions) >= max_questions:
                break
                
            try:
                # Extract question text (everything until the first option)
                first_option_match = re.search(r'[A-D]\)', block)
                if first_option_match:
                    question_text = block[:first_option_match.start()].strip()
                else:
                    question_text = f"Question {i+1}"
                
                # Extract options
                options = []
                for option in [r'A\)', r'B\)', r'C\)', r'D\)']:
                    option_match = re.search(rf'{option}\s*([^\n]+)', block)
                    if option_match:
                        options.append(option_match.group(1).strip())
                    else:
                        options.append(f"Option {option[0]}")
                
                # Extract answer
                answer_match = re.search(r'Answer:\s*([A-D])', block)
                correct_answer = answer_match.group(1) if answer_match else "A"
                
                # Clean up options to remove calculations and make them simpler
                cleaned_options = []
                for option in options:
                    # Remove common calculation patterns
                    cleaned_option = option
                    if '=' in option:
                        # Extract just the result part after '='
                        parts = option.split('=')
                        if len(parts) > 1:
                            cleaned_option = parts[-1].strip()
                    # Remove extra spaces and clean up
                    cleaned_option = cleaned_option.strip()
                    cleaned_options.append(cleaned_option)
                
                # Convert to JSON format
                questions.append({
                    "question": question_text,
                    "options": cleaned_options,
                    "answer": f"Option {correct_answer}"
                })
                
            except Exception as e:
                print(f"Error parsing question block {i}: {e}")
                continue
        
        return questions
    
    questions = parse_qa_to_json(result, num_questions)
    
    # Fallback to sample questions if parsing fails
    if not questions:
        print("Q&A parsing failed, using sample questions")
        questions = [
            {
                "question": f"Sample question {i+1} on {topic} ({difficulty})?",
                "options": ["Option A", "Option B", "Option C", "Option D"],
                "answer": "Option A"
            } for i in range(num_questions)
        ]
    
    return questions

@app.post('/generate_quiz')
def generate_quiz(data: Dict = Body(...)):
    topic = data.get("topic") or "General"
    difficulty = data.get("difficulty") or "easy"
    num_questions = data.get("num_questions", 5)
    quiz = generate_mcqs_watsonx(topic, difficulty, num_questions)
    quiz_no_answers = [{"question": q["question"], "options": q["options"]} for q in quiz]
    return {"quiz": quiz_no_answers, "_answers": [q["answer"] for q in quiz]}

@app.post('/submit_quiz')
def submit_quiz(data: Dict = Body(...)):
    user_id = data.get("user_id")
    answers = data.get("answers", {})
    quiz = data.get("quiz", [])
    topic = data.get("topic")
    difficulty = data.get("difficulty")
    correct_answers = [q.get("answer", "Option A") for q in quiz]
    
    feedback = {}
    score = 0
    for idx, q in enumerate(quiz):
        # Try both string and integer keys
        user_ans = answers.get(str(idx)) or answers.get(idx)
        correct_ans_label = correct_answers[idx]
        
        # Convert option label (e.g., "Option A") to actual option text
        correct_ans_text = correct_ans_label
        if correct_ans_label.startswith("Option "):
            option_letter = correct_ans_label[-1]  # Get A, B, C, or D
            option_index = ord(option_letter) - ord('A')  # Convert A=0, B=1, C=2, D=3
            if 0 <= option_index < len(q.get("options", [])):
                correct_ans_text = q["options"][option_index]
        
        # Robust comparison - try exact match first, then case-insensitive
        is_correct = False
        if user_ans == correct_ans_text:
            is_correct = True
        elif user_ans and correct_ans_text and user_ans.strip().lower() == correct_ans_text.strip().lower():
            is_correct = True
        elif user_ans and correct_ans_text and user_ans.strip() == correct_ans_text.strip():
            is_correct = True
        
        feedback[str(idx)] = {
            "correct": is_correct,
            "user_answer": user_ans,
            "correct_answer": correct_ans_text
        }
        if is_correct:
            score += 1
    import json
    
    meta = {
        "user_id": user_id,
        "topic": topic,
        "difficulty": difficulty,
        "score": score,
        "total": len(quiz),
        "date": datetime.now().isoformat(),
        "questions": json.dumps([
            {
                "question": q.get("question"),
                "options": q.get("options"),
                "correct_answer": (
                    q.get("options")[ord(q.get("answer")[-1]) - ord('A')] if q.get("answer", "").startswith("Option ") else q.get("answer")
                )
            }
            for q in quiz
        ]),
        "user_answers": json.dumps([
            answers.get(str(idx)) or answers.get(idx) for idx in range(len(quiz))
        ])
    }
    import uuid
    import random
    quiz_id = str(uuid.uuid4())
    
    # Generate a vector with some non-zero values (Pinecone requirement)
    vector = [0.0] * 1024
    # Set a few random values to non-zero
    for i in range(10):
        vector[random.randint(0, 1023)] = random.uniform(0.1, 1.0)
    
    # Save quiz record
    index.upsert([
        (quiz_id, vector, meta)
    ], namespace=user_id)
    # Save student in students_list namespace
    index.upsert([
        (user_id, [1.0] * 1024, {"user_id": user_id})
    ], namespace="students_list")
    return {"feedback": feedback, "score": score, "total": len(quiz)}

@app.get('/educator_dashboard')
def educator_dashboard():
    """Get educator dashboard analytics with real data"""
    try:
        # First, get all students from the students_list namespace
        students_res = index.query(
            vector=[1.0] * 1024,
            top_k=1000,
            include_metadata=True,
            namespace="students_list"
        )
        
        students = []
        for match in getattr(students_res, 'matches', []):
            meta = match.get('metadata', {})
            user_id = meta.get('user_id')
            if user_id:
                students.append(user_id)
        
        total_students = len(students)
        total_quizzes = 0
        total_score = 0
        total_questions = 0
        
        # For each student, get their quiz history to calculate totals
        for student_id in students:
            try:
                # Query student's quiz history
                query_vector = [0.0] * 1024
                query_vector[0] = 0.1  # Set at least one non-zero value
                
                student_res = index.query(
                    vector=query_vector,
                    top_k=100,
                    include_metadata=True,
                    namespace=student_id
                )
                
                matches = getattr(student_res, 'matches', [])
                for match in matches:
                    meta = match.get('metadata', {})
                    if meta.get('user_id') == student_id:
                        total_quizzes += 1
                        total_score += int(meta.get('score', 0))
                        total_questions += int(meta.get('total', 0))
                        
            except Exception as e:
                print(f"Error querying student {student_id}: {str(e)}")
                continue
        
        # Calculate average class score
        avg_class_score = (total_score / total_questions * 100) if total_questions > 0 else 0
        
        return {
            "total_students": total_students,
            "total_quizzes": total_quizzes,
            "avg_class_score": round(avg_class_score, 1)
        }
    except Exception as e:
        print(f"Error in educator_dashboard: {str(e)}")
        # Return default values if query fails
        return {
            "total_students": 0,
            "total_quizzes": 0,
            "avg_class_score": 0
        }

@app.get('/educator/students')
def get_all_students():
    try:
        res = index.query(
            vector=[1.0] * 1024,
            top_k=1000,
            include_metadata=True,
            namespace="students_list"
        )
        students = []
        for match in getattr(res, 'matches', []):
            meta = match.get('metadata', {})
            user_id = meta.get('user_id')
            if user_id:
                students.append(user_id)
        return {"students": students}
    except Exception as e:
        print(f"Error in get_all_students: {str(e)}")
        return {"students": []}

@app.get('/educator/student/{user_id}/quiz-history')
def get_student_quiz_history(user_id: str):
    # Generate a query vector with some non-zero values
    query_vector = [0.0] * 1024
    query_vector[0] = 0.1  # Set at least one non-zero value
    
    res = index.query(
        vector=query_vector,
        top_k=100,
        include_metadata=True,
        namespace=user_id
    )
    history = []
    matches = getattr(res, 'matches', [])
    for match in matches:
        meta = match.get('metadata', {})
        history.append(meta)
    return {"user_id": user_id, "quiz_history": history}

@app.get('/student_dashboard/{user_id}')
def student_dashboard(user_id: str):
    """Get student dashboard analytics with real data"""
    try:
        # Query student's quiz history
        query_vector = [0.0] * 1024
        query_vector[0] = 0.1  # Set at least one non-zero value
        
        res = index.query(
            vector=query_vector,
            top_k=100,
            include_metadata=True,
            namespace=user_id
        )
        
        total_quizzes = 0
        total_score = 0
        total_questions = 0
        quiz_dates = []
        
        matches = getattr(res, 'matches', [])
        for match in matches:
            meta = match.get('metadata', {})
            if meta.get('user_id') == user_id:
                total_quizzes += 1
                total_score += int(meta.get('score', 0))
                total_questions += int(meta.get('total', 0))
                quiz_date = meta.get('date', '')
                if quiz_date:
                    quiz_dates.append(quiz_date)
        
        # Calculate average score
        avg_score = (total_score / total_questions * 100) if total_questions > 0 else 0
        
        # Calculate learning streak (consecutive days with quizzes)
        learning_streak = 0
        if quiz_dates:
            # Sort dates and calculate consecutive days
            from datetime import datetime, timedelta
            try:
                sorted_dates = sorted([datetime.fromisoformat(date.replace('Z', '+00:00')) for date in quiz_dates])
                current_streak = 1
                max_streak = 1
                
                for i in range(1, len(sorted_dates)):
                    date_diff = (sorted_dates[i] - sorted_dates[i-1]).days
                    if date_diff == 1:  # Consecutive days
                        current_streak += 1
                        max_streak = max(max_streak, current_streak)
                    else:
                        current_streak = 1
                
                learning_streak = max_streak
            except:
                learning_streak = len(quiz_dates)  # Fallback to total quizzes if date parsing fails
        
        return {
            "total_quizzes": total_quizzes,
            "avg_score": round(avg_score, 1),
            "learning_streak": learning_streak,
            "total_questions": total_questions
        }
    except Exception as e:
        print(f"Error in student_dashboard: {str(e)}")
        return {
            "total_quizzes": 0,
            "avg_score": 0,
            "learning_streak": 0,
            "total_questions": 0
        } 