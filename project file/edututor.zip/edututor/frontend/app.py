import streamlit as st
import requests

st.set_page_config(page_title="EduTutor AI", layout="wide")
API_URL = "http://localhost:8000"  # Adjust if backend runs elsewhere

# Enhanced CSS for modern UI/UX
st.markdown('''
    <style>
    /* Global Styles */
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        text-align: center;
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    }
    
    .main-header h1 {
        color: white;
        font-size: 2.5rem;
        font-weight: 700;
        margin: 0;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .main-header p {
        color: rgba(255,255,255,0.9);
        font-size: 1.1rem;
        margin: 0.5rem 0 0 0;
    }
    
    /* Login Styles */
    .top-card {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 0;
        padding-top: 2rem;
        min-height: auto;
        justify-content: flex-start;
    }
    
    .login-box {
        background: linear-gradient(145deg, #2a2d3a, #1e2127);
        padding: 3rem;
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        min-width: 400px;
        max-width: 450px;
        border: 1px solid rgba(255,255,255,0.1);
        backdrop-filter: blur(10px);
        animation: slideIn 0.6s ease-out;
    }
    
    @keyframes slideIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .login-title {
        font-size: 2.2rem;
        font-weight: 700;
        background: linear-gradient(45deg, #ffe066, #ffd700);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.8rem;
        text-align: center;
    }
    
    .login-title svg {
        width: 2.2rem;
        height: 2.2rem;
        filter: drop-shadow(2px 2px 4px rgba(0,0,0,0.3));
    }
    
    /* Form Styles */
    .stSelectbox, .stTextInput {
        margin-bottom: 1.5rem;
    }
    
    .stButton > button {
        background: linear-gradient(45deg, #667eea, #764ba2);
        border: none;
        border-radius: 25px;
        padding: 0.8rem 2rem;
        font-weight: 600;
        font-size: 1.1rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
    }
    
    /* Sidebar Enhancement */
    .css-1d391kg {
        background: linear-gradient(180deg, #2a2d3a 0%, #1e2127 100%);
    }
    
    .css-1d391kg .sidebar-content {
        padding: 2rem 1rem;
    }
    
    /* Card Styles */
    .dashboard-card {
        background: linear-gradient(145deg, #2a2d3a, #1e2127);
        border-radius: 15px;
        padding: 2rem;
        margin: 1rem 0;
        border: 1px solid rgba(255,255,255,0.1);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
    }
    
    .dashboard-card:hover {
        transform: translateY(-5px);
    }
    
    /* Quiz Form Styles */
    .quiz-form-container {
        background: linear-gradient(145deg, #2a2d3a, #1e2127);
        border-radius: 20px;
        padding: 2.5rem;
        margin: 2rem 0;
        border: 1px solid rgba(255,255,255,0.1);
        box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    }
    
    .quiz-question {
        background: rgba(255,255,255,0.05);
        border-radius: 12px;
        padding: 1.5rem;
        margin: 1rem 0;
        border-left: 4px solid #667eea;
        transition: all 0.3s ease;
    }
    
    .quiz-question:hover {
        background: rgba(255,255,255,0.08);
        transform: translateX(5px);
    }
    
    /* Success/Error Messages */
    .stSuccess {
        background: linear-gradient(45deg, #4CAF50, #45a049);
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        border: none;
        color: white;
        font-weight: 600;
    }
    
    .stError {
        background: linear-gradient(45deg, #f44336, #d32f2f);
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        border: none;
        color: white;
        font-weight: 600;
    }
    
    /* Loading Animation */
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255,255,255,.3);
        border-radius: 50%;
        border-top-color: #fff;
        animation: spin 1s ease-in-out infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .login-box {
            min-width: 300px;
            padding: 2rem;
        }
        
        .main-header h1 {
            font-size: 2rem;
        }
    }
    </style>
''', unsafe_allow_html=True)

if "user_id" not in st.session_state:
    st.session_state.user_id = None
if "role" not in st.session_state:
    st.session_state.role = None

if st.session_state.user_id is None:
    st.markdown('<div class="top-card">', unsafe_allow_html=True)
    st.markdown('<div class="login-box">', unsafe_allow_html=True)
    st.markdown('''<div class="login-title">
        <svg fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#ffe066"/><path d="M12 7v5l3 3" stroke="#23272f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        EduTutor AI Login
    </div>''', unsafe_allow_html=True)
    role = st.selectbox("Select Role", ["student", "educator"])
    user_id = st.text_input("Enter User ID")
    login_btn = st.button("Login")
    if login_btn:
        if user_id:
            # Clear all quiz-related session state when logging in as a new user
            if "current_quiz" in st.session_state:
                del st.session_state.current_quiz
            if "correct_answers" in st.session_state:
                del st.session_state.correct_answers
            if "quiz_topic" in st.session_state:
                del st.session_state.quiz_topic
            if "quiz_difficulty" in st.session_state:
                del st.session_state.quiz_difficulty
            if "quiz_answers" in st.session_state:
                del st.session_state.quiz_answers
            if "page" in st.session_state:
                del st.session_state.page
            
            st.session_state.user_id = user_id
            st.session_state.role = role
            st.success(f"Logged in as {user_id} ({role})")
            st.rerun()
        else:
            st.error("User ID required.")
    st.markdown('</div></div>', unsafe_allow_html=True)
    st.stop()

user_id = st.session_state.user_id
role = st.session_state.role

# Enhanced Sidebar navigation
st.sidebar.markdown('''
    <div style="text-align: center; padding: 1rem 0;">
        <h2 style="color: #ffe066; margin-bottom: 0.5rem;">🎓 EduTutor AI</h2>
        <p style="color: #888; font-size: 0.9rem; margin: 0;">Learning Made Smart</p>
    </div>
''', unsafe_allow_html=True)

st.sidebar.markdown("---")

# User info
st.sidebar.markdown(f'''
    <div style="background: rgba(255,255,255,0.05); padding: 1rem; border-radius: 10px; margin-bottom: 1rem;">
        <p style="color: #ffe066; font-weight: bold; margin: 0;">👤 {user_id}</p>
        <p style="color: #888; font-size: 0.8rem; margin: 0;">Role: {role.title() if role else 'N/A'}</p>
    </div>
''', unsafe_allow_html=True)

# Role-based navigation
if role == "educator":
    page = st.sidebar.radio("📱 Navigation", ["Dashboard", "Student Quiz History"])
else:
    page = st.sidebar.radio("📱 Navigation", ["Dashboard", "Take Quiz", "Quiz History"])

st.sidebar.markdown("---")

# Logout button
if st.sidebar.button("🚪 Logout", use_container_width=True):
    # Clear all session state when logging out
    st.session_state.clear()
    st.rerun()

if page == "Dashboard":
    if role == "educator":
        st.markdown(f'''
            <div class="main-header">
                <h1>👨‍🏫 Educator Dashboard</h1>
                <p>Welcome {user_id}! Monitor your students' learning progress and performance.</p>
            </div>
        ''', unsafe_allow_html=True)
        
        # Fetch real analytics data from backend
        try:
            resp = requests.get(f"{API_URL}/educator_dashboard")
            if resp.status_code == 200:
                analytics = resp.json()
                total_students = analytics.get("total_students", 0)
                total_quizzes = analytics.get("total_quizzes", 0)
                avg_class_score = analytics.get("avg_class_score", 0)
            else:
                total_students = 0
                total_quizzes = 0
                avg_class_score = 0
        except:
            total_students = 0
            total_quizzes = 0
            avg_class_score = 0
        
        # Educator Dashboard Stats Cards
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown(f'''
                <div class="dashboard-card">
                    <h3>👥 Total Students</h3>
                    <p style="font-size: 2rem; color: #667eea; font-weight: bold;">{total_students}</p>
                    <p style="color: #888;">Active students in your class</p>
                </div>
            ''', unsafe_allow_html=True)
        
        with col2:
            st.markdown(f'''
                <div class="dashboard-card">
                    <h3>📊 Total Quizzes</h3>
                    <p style="font-size: 2rem; color: #4CAF50; font-weight: bold;">{total_quizzes}</p>
                    <p style="color: #888;">Quizzes taken by students</p>
                </div>
            ''', unsafe_allow_html=True)
        
        with col3:
            st.markdown(f'''
                <div class="dashboard-card">
                    <h3>📈 Avg Class Score</h3>
                    <p style="font-size: 2rem; color: #ffd700; font-weight: bold;">{avg_class_score}%</p>
                    <p style="color: #888;">Overall class performance</p>
                </div>
            ''', unsafe_allow_html=True)
        
        # Quick Actions for Educators
        st.markdown('''
            <div class="dashboard-card">
                <h3>🚀 Quick Actions</h3>
                <p>Monitor student progress and review quiz performance:</p>
            </div>
        ''', unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("👥 View Student List", use_container_width=True):
                st.session_state.page = "Student Quiz History"
                st.rerun()
        
        with col2:
            if st.button("📊 Analytics Report", use_container_width=True):
                st.info("Analytics report feature coming soon!")
    
    else:
        # Student Dashboard with real data
        st.markdown(f'''
            <div class="main-header">
                <h1>🎓 Welcome to EduTutor AI</h1>
                <p>Hello {user_id}! Ready to enhance your learning journey?</p>
            </div>
        ''', unsafe_allow_html=True)
        
        # Fetch real student analytics data from backend
        try:
            resp = requests.get(f"{API_URL}/student_dashboard/{user_id}")
            if resp.status_code == 200:
                analytics = resp.json()
                total_quizzes = analytics.get("total_quizzes", 0)
                avg_score = analytics.get("avg_score", 0)
                learning_streak = analytics.get("learning_streak", 0)
            else:
                total_quizzes = 0
                avg_score = 0
                learning_streak = 0
        except:
            total_quizzes = 0
            avg_score = 0
            learning_streak = 0
        
        # Dashboard Stats Cards with real data
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown(f'''
                <div class="dashboard-card">
                    <h3>📚 Total Quizzes</h3>
                    <p style="font-size: 2rem; color: #667eea; font-weight: bold;">{total_quizzes}</p>
                    <p style="color: #888;">{'Start your first quiz!' if total_quizzes == 0 else 'Quizzes completed'}</p>
                </div>
            ''', unsafe_allow_html=True)
        
        with col2:
            st.markdown(f'''
                <div class="dashboard-card">
                    <h3>🎯 Average Score</h3>
                    <p style="font-size: 2rem; color: #4CAF50; font-weight: bold;">{avg_score}%</p>
                    <p style="color: #888;">{'Take quizzes to see your progress' if avg_score == 0 else 'Your performance'}</p>
                </div>
            ''', unsafe_allow_html=True)
        
        with col3:
            st.markdown(f'''
                <div class="dashboard-card">
                    <h3>📈 Learning Streak</h3>
                    <p style="font-size: 2rem; color: #ffd700; font-weight: bold;">{learning_streak}</p>
                    <p style="color: #888;">{'Days of consistent learning' if learning_streak > 0 else 'Start building your streak'}</p>
                </div>
            ''', unsafe_allow_html=True)
        


elif page == "Take Quiz":
    st.markdown(f'''
        <div class="main-header">
            <h1>🎯 Take a Quiz</h1>
            <p>Test your knowledge with AI-generated questions</p>
        </div>
    ''', unsafe_allow_html=True)
    
    st.markdown('<div class="quiz-form-container">', unsafe_allow_html=True)
    with st.form("quiz_form"):
        st.markdown("### 📝 Quiz Configuration")
        topic = st.text_input("🎯 What topic would you like to test?")
        difficulty = st.selectbox("📊 Difficulty Level", ["easy", "medium", "hard"], help="Choose the difficulty level that matches your knowledge")
        num_questions = st.slider("❓ Number of Questions", 1, 10, 5, help="Select how many questions you want in your quiz")
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            submitted = st.form_submit_button("🚀 Generate Quiz", use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    if submitted and topic:
        with st.spinner("🤖 AI is generating your quiz... Please wait."):
            resp = requests.post(f"{API_URL}/generate_quiz", json={"topic": topic, "difficulty": difficulty, "num_questions": num_questions})
            if resp.status_code == 200:
                data = resp.json()
                quiz = data.get("quiz", [])
                answers = data.get("_answers", [])
                st.session_state.current_quiz = quiz
                st.session_state.correct_answers = answers
                st.session_state.quiz_topic = topic
                st.session_state.quiz_difficulty = difficulty
                st.session_state.quiz_answers = {}
                st.success("🎉 Quiz generated successfully! Answer the questions below.")
            else:
                st.error("❌ Failed to generate quiz. Please try again.")

    if "current_quiz" in st.session_state and st.session_state.current_quiz:
        st.markdown(f'''
            <div class="dashboard-card">
                <h2>📋 Quiz: {st.session_state.quiz_topic} ({st.session_state.quiz_difficulty})</h2>
                <p>Answer all questions below. Take your time and think carefully!</p>
            </div>
        ''', unsafe_allow_html=True)
        
        answers = {}
        for idx, q in enumerate(st.session_state.current_quiz):
            st.markdown(f'''
                <div class="quiz-question">
                    <h4 style="color: #667eea; margin-bottom: 1rem;">Question {idx+1}</h4>
                    <p style="font-size: 1.1rem; margin-bottom: 1.5rem;">{q['question']}</p>
                </div>
            ''', unsafe_allow_html=True)
            answers[idx] = st.radio(f"Select your answer:", q['options'], key=f"q{idx}")
            st.markdown("<br>", unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            if st.button("📤 Submit Quiz", use_container_width=True):
                # Add correct answers to quiz data
                quiz_with_answers = []
                for i, q in enumerate(st.session_state.current_quiz):
                    quiz_with_answers.append({
                        "question": q["question"],
                        "options": q["options"],
                        "answer": st.session_state.correct_answers[i] if i < len(st.session_state.correct_answers) else "Option A"
                    })
                
                with st.spinner("📤 Submitting your quiz..."):
                    resp = requests.post(f"{API_URL}/submit_quiz", json={"user_id": user_id, "answers": answers, "quiz": quiz_with_answers, "topic": st.session_state.quiz_topic, "difficulty": st.session_state.quiz_difficulty})
                    if resp.status_code == 200:
                        feedback = resp.json().get("feedback", {})
                        st.session_state.quiz_feedback = feedback
                        st.success("🎉 Quiz submitted successfully! See your results below.")
                    else:
                        st.error("❌ Failed to submit quiz. Please try again.")

    if "quiz_feedback" in st.session_state:
        st.markdown(f'''
            <div class="dashboard-card">
                <h2>📊 Quiz Results</h2>
                <p>Here's how you performed on your quiz:</p>
            </div>
        ''', unsafe_allow_html=True)
        
        feedback = st.session_state.quiz_feedback
        correct_count = sum(1 for result in feedback.values() if result["correct"])
        total_questions = len(feedback)
        score_percentage = (correct_count / total_questions) * 100 if total_questions > 0 else 0
        
        # Score summary
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Questions", total_questions)
        with col2:
            st.metric("Correct Answers", correct_count)
        with col3:
            st.metric("Score", f"{score_percentage:.1f}%")
        
        # Detailed feedback
        for idx, result in feedback.items():
            q = st.session_state.current_quiz[int(idx)]
            correct = result["correct"]
            user_ans = result["user_answer"]
            correct_ans = result["correct_answer"]
            
            if correct:
                st.markdown(f'''
                    <div style="background: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 15px; margin: 10px 0; border-radius: 5px;">
                        <span style="color: #4CAF50; font-weight: bold; font-size: 1.1em;">✓ Question {int(idx)+1}: Correct!</span>
                        <p style="margin: 5px 0 0 0; color: #666;">Your answer: <strong>{user_ans}</strong></p>
                    </div>
                ''', unsafe_allow_html=True)
            else:
                st.markdown(f'''
                    <div style="background: rgba(244, 67, 54, 0.1); border-left: 4px solid #f44336; padding: 15px; margin: 10px 0; border-radius: 5px;">
                        <span style="color: #f44336; font-weight: bold; font-size: 1.1em;">✗ Question {int(idx)+1}: Incorrect</span>
                        <p style="margin: 5px 0 0 0; color: #666;">Your answer: <strong>{user_ans}</strong> | Correct answer: <strong style="color: #4CAF50;">{correct_ans}</strong></p>
                    </div>
                ''', unsafe_allow_html=True)

elif page == "Quiz History":
    st.markdown(f'''
        <div class="main-header">
            <h1>📚 Quiz History</h1>
            <p>Review your past quizzes and track your learning progress</p>
        </div>
    ''', unsafe_allow_html=True)
    
    # Add custom CSS for quiz history styling
    st.markdown('''
        <style>
        .quiz-card {
            background: #1e1e1e;
            border: 1px solid #333;
            border-radius: 10px;
            padding: 20px;
            margin: 15px 0;
        }
        .quiz-header {
            color: #ffe066;
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 10px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .question-container {
            background: #2a2a2a;
            border-left: 4px solid #ff4b4b;
            padding: 15px;
            margin: 15px 0;
            border-radius: 5px;
        }
        .question-text {
            color: #ff4b4b;
            font-weight: bold;
            font-size: 1.1em;
            margin-bottom: 10px;
        }
        .options-list {
            color: #ffffff;
            margin: 10px 0;
            padding-left: 20px;
        }
        .answer-info {
            background: #333;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .correct-answer {
            color: #4CAF50;
            font-weight: bold;
        }
        .user-answer {
            color: #FF9800;
            font-weight: bold;
        }
        .score-info {
            color: #ffe066;
            font-size: 1.1em;
            font-weight: bold;
        }
        .date-info {
            color: #888;
            font-style: italic;
        }
        </style>
    ''', unsafe_allow_html=True)
    
    resp = requests.get(f"{API_URL}/educator/student/{user_id}/quiz-history")
    if resp.status_code == 200:
        history = resp.json().get("quiz_history", [])
        if not history:
            st.info("No quiz history found.")
        for i, quiz in enumerate(history):
            st.markdown(f'''
                <div class="quiz-card">
                    <div class="quiz-header">Quiz {i+1}: {quiz.get('topic', 'N/A')} ({quiz.get('difficulty', 'N/A')})</div>
                    <div class="score-info">Score: {quiz.get('score', 'N/A')}</div>
                    <div class="date-info">Date: {quiz.get('date', 'N/A')}</div>
                </div>
            ''', unsafe_allow_html=True)
            
            import json
            
            questions_json = quiz.get('questions', '[]')
            user_answers_json = quiz.get('user_answers', '[]')
            
            try:
                questions = json.loads(questions_json) if isinstance(questions_json, str) else questions_json
                user_answers = json.loads(user_answers_json) if isinstance(user_answers_json, str) else user_answers_json
                
                if questions:
                    for idx, q in enumerate(questions):
                        # Format options as a list
                        options_text = ""
                        if q.get('options'):
                            options_list = q.get('options')
                            if isinstance(options_list, list):
                                options_text = "<br>".join([f"• {opt}" for opt in options_list])
                            else:
                                options_text = str(options_list)
                        
                        user_ans = user_answers[idx] if idx < len(user_answers) else 'N/A'
                        
                        st.markdown(f'''
                            <div class="question-container">
                                <div class="question-text">Q{idx+1}: {q.get('question')}</div>
                                <div class="options-list">{options_text}</div>
                                <div class="answer-info">
                                    <div class="correct-answer">✓ Correct Answer: {q.get('correct_answer')}</div>
                                    <div class="user-answer">Your Answer: {user_ans}</div>
                                </div>
                            </div>
                        ''', unsafe_allow_html=True)
                else:
                    st.write("No question details available.")
            except (json.JSONDecodeError, TypeError):
                st.write("Error parsing quiz details.")
    else:
        st.error("Failed to fetch quiz history.")

elif page == "Student Quiz History":
    # Enhanced CSS for better educator quiz history UI
    st.markdown('''
        <style>
        .educator-quiz-card {
            background: linear-gradient(145deg, #2a2d3a, #1e2127);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 25px;
            margin: 20px 0;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .educator-quiz-card:hover {
            transform: translateY(-2px);
        }
        .educator-quiz-header {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            font-size: 1.3em;
            font-weight: bold;
            margin: -25px -25px 20px -25px;
            padding: 20px 25px;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .educator-quiz-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            padding: 15px;
            background: rgba(255,255,255,0.05);
            border-radius: 10px;
        }
        .educator-stat-item {
            text-align: center;
            flex: 1;
        }
        .educator-stat-value {
            font-size: 1.5em;
            font-weight: bold;
            color: #ffe066;
        }
        .educator-stat-label {
            font-size: 0.9em;
            color: #888;
            margin-top: 5px;
        }
        .educator-question-section {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        .educator-question-header {
            color: #ffe066;
            font-size: 1.1em;
            font-weight: bold;
            margin-bottom: 15px;
            padding: 10px;
            background: rgba(255,255,255,0.05);
            border-radius: 8px;
        }
        .educator-question-container {
            background: rgba(255,255,255,0.03);
            border-left: 4px solid #667eea;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .educator-question-container:hover {
            background: rgba(255,255,255,0.05);
            transform: translateX(5px);
        }
        .educator-question-text {
            color: #ffffff;
            font-weight: bold;
            font-size: 1.1em;
            margin-bottom: 15px;
            line-height: 1.4;
        }
        .educator-options-list {
            color: #cccccc;
            margin: 15px 0;
            padding-left: 25px;
            line-height: 1.6;
        }
        .educator-options-list br {
            margin-bottom: 8px;
        }
        .educator-answer-section {
            background: rgba(255,255,255,0.05);
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .educator-correct-answer {
            color: #4CAF50;
            font-weight: bold;
            margin-bottom: 8px;
            padding: 8px;
            background: rgba(76, 175, 80, 0.1);
            border-radius: 5px;
        }
        .educator-user-answer {
            font-weight: bold;
            padding: 8px;
            border-radius: 5px;
            margin-top: 8px;
        }
        .educator-user-answer.correct {
            color: #4CAF50;
            background: rgba(76, 175, 80, 0.1);
        }
        .educator-user-answer.incorrect {
            color: #f44336;
            background: rgba(244, 67, 54, 0.1);
        }
        .educator-date-info {
            color: #888;
            font-style: italic;
            text-align: right;
            margin-top: 10px;
        }
        </style>
    ''', unsafe_allow_html=True)
    
    st.markdown(f'''
        <div class="main-header">
            <h1>👥 Student Quiz History</h1>
            <p>Select a student to view their quiz performance and history</p>
        </div>
    ''', unsafe_allow_html=True)
    
    # Get list of students
    resp = requests.get(f"{API_URL}/educator/students")
    if resp.status_code == 200:
        students = resp.json().get("students", [])
        
        if not students:
            st.warning("No students found.")
        else:
            # Student selection
            st.markdown('<div class="quiz-form-container">', unsafe_allow_html=True)
            st.markdown("### 👤 Select Student")
            selected_student = st.selectbox("Choose a student to view their quiz history:", students)
            st.markdown('</div>', unsafe_allow_html=True)
            
            if selected_student:
                # Get selected student's quiz history
                resp = requests.get(f"{API_URL}/educator/student/{selected_student}/quiz-history")
                if resp.status_code == 200:
                    history = resp.json().get("quiz_history", [])
                    
                    if not history:
                        st.info(f"No quiz history found for {selected_student}.")
                    else:
                        # Student performance summary
                        total_quizzes = len(history)
                        total_score = sum(int(quiz.get('score', 0)) for quiz in history)
                        total_questions = sum(int(quiz.get('total', 0)) for quiz in history)
                        avg_score = (total_score / total_questions * 100) if total_questions > 0 else 0
                        
                        # Enhanced performance summary
                        st.markdown(f'''
                            <div class="educator-quiz-card">
                                <div class="educator-quiz-header">
                                    📊 {selected_student}'s Performance Overview
                                </div>
                                <div class="educator-quiz-stats">
                                    <div class="educator-stat-item">
                                        <div class="educator-stat-value">{total_quizzes}</div>
                                        <div class="educator-stat-label">Total Quizzes</div>
                                    </div>
                                    <div class="educator-stat-item">
                                        <div class="educator-stat-value">{total_questions}</div>
                                        <div class="educator-stat-label">Total Questions</div>
                                    </div>
                                    <div class="educator-stat-item">
                                        <div class="educator-stat-value">{avg_score:.1f}%</div>
                                        <div class="educator-stat-label">Average Score</div>
                                    </div>
                                </div>
                            </div>
                        ''', unsafe_allow_html=True)
                        
                        # Detailed quiz history
                        for i, quiz in enumerate(history):
                            score_percentage = (int(quiz.get('score', 0)) / int(quiz.get('total', 1)) * 100) if int(quiz.get('total', 1)) > 0 else 0
                            
                            st.markdown(f'''
                                <div class="educator-quiz-card">
                                    <div class="educator-quiz-header">
                                        <span>📝 Quiz {i+1}: {quiz.get('topic', 'N/A')} ({quiz.get('difficulty', 'N/A')})</span>
                                        <span>Score: {quiz.get('score', 'N/A')}/{quiz.get('total', 'N/A')} ({score_percentage:.1f}%)</span>
                                    </div>
                                    <div class="educator-date-info">📅 {quiz.get('date', 'N/A')}</div>
                            ''', unsafe_allow_html=True)
                            
                            import json
                            
                            questions_json = quiz.get('questions', '[]')
                            user_answers_json = quiz.get('user_answers', '[]')
                            
                            try:
                                questions = json.loads(questions_json) if isinstance(questions_json, str) else questions_json
                                user_answers = json.loads(user_answers_json) if isinstance(user_answers_json, str) else user_answers_json
                                
                                if questions:
                                    st.markdown('<div class="educator-question-section">', unsafe_allow_html=True)
                                    st.markdown('<div class="educator-question-header">📋 Questions & Answers</div>', unsafe_allow_html=True)
                                    
                                    for idx, q in enumerate(questions):
                                        # Format options as a list
                                        options_text = ""
                                        if q.get('options'):
                                            options_list = q.get('options')
                                            if isinstance(options_list, list):
                                                options_text = "<br>".join([f"• {opt}" for opt in options_list])
                                            else:
                                                options_text = str(options_list)
                                        
                                        user_ans = user_answers[idx] if idx < len(user_answers) else 'N/A'
                                        correct_ans = q.get('correct_answer', 'N/A')
                                        
                                        # Determine if answer was correct
                                        is_correct = user_ans == correct_ans
                                        answer_class = "correct" if is_correct else "incorrect"
                                        answer_icon = "✓" if is_correct else "✗"
                                        
                                        st.markdown(f'''
                                            <div class="educator-question-container">
                                                <div class="educator-question-text">Q{idx+1}: {q.get('question')}</div>
                                                <div class="educator-options-list">{options_text}</div>
                                                <div class="educator-answer-section">
                                                    <div class="educator-correct-answer">✓ Correct Answer: {correct_ans}</div>
                                                    <div class="educator-user-answer {answer_class}">{answer_icon} Student Answer: {user_ans}</div>
                                                </div>
                                            </div>
                                        ''', unsafe_allow_html=True)
                                    
                                    st.markdown('</div>', unsafe_allow_html=True)
                                else:
                                    st.write("No question details available.")
                            except (json.JSONDecodeError, TypeError):
                                st.write("Error parsing quiz details.")
                            
                            st.markdown('</div>', unsafe_allow_html=True)
                else:
                    st.error(f"Failed to fetch quiz history for {selected_student}.")
    else:
        st.error("Failed to fetch student list.") 